"""
Meshing-Around Web GUI - FastAPI Backend
Configuration management API for MeshBOT
"""

import os
import re
import json
import shutil
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel

from config_schema import CONFIG_SCHEMA, SECTION_ORDER, INTERFACE_FIELDS, PRIMARY_INTERFACE_FIELDS

# Configuration
CONFIG_PATH = os.environ.get("CONFIG_PATH", "/opt/meshing-around/config.ini")
BACKUP_DIR = os.environ.get("BACKUP_DIR", "/opt/meshing-around/webgui/backups")
SERVICE_NAME = os.environ.get("SERVICE_NAME", "meshbot")
SCHEDULES_PATH = Path(__file__).parent / "schedules.json"

app = FastAPI(
    title="MeshBOT Config Manager",
    description="Web GUI for managing meshing-around configuration",
    version="1.0.0"
)

# CORS for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
static_path = Path(__file__).parent / "static"
if static_path.exists():
    app.mount("/static", StaticFiles(directory=str(static_path)), name="static")


class ConfigUpdate(BaseModel):
    """Model for config updates"""
    section: str
    key: str
    value: Any


class BulkConfigUpdate(BaseModel):
    """Model for bulk config updates"""
    updates: Dict[str, Dict[str, Any]]


class InterfaceUpdate(BaseModel):
    """Model for interface updates"""
    enabled: Optional[bool] = None
    type: Optional[str] = None
    port: Optional[str] = None
    hostname: Optional[str] = None
    mac: Optional[str] = None


class ScheduleItem(BaseModel):
    """Model for a scheduled item"""
    id: Optional[int] = None
    enabled: bool = True
    name: str = ""
    frequency: str = "day"  # minutes, hours, day, days, or weekday name
    time: Optional[str] = None  # HH:MM format
    interval: Optional[int] = None  # for minutes/hours/days
    day: Optional[str] = None  # for specific weekday
    message: str = ""
    action: str = "message"  # message, weather, joke, news, rss, etc.
    channel: int = 0
    interface: int = 1


class ConfigParser:
    """Custom config parser that preserves comments and formatting"""

    def __init__(self, path: str):
        self.path = path
        self.lines: List[str] = []
        self.sections: Dict[str, Dict[str, str]] = {}
        self.comments: Dict[str, Dict[str, str]] = {}

    def read(self) -> Dict[str, Dict[str, str]]:
        """Read config file preserving structure"""
        self.lines = []
        self.sections = {}
        self.comments = {}

        current_section = None
        current_comment = []

        with open(self.path, 'r', encoding='utf-8') as f:
            for line in f:
                self.lines.append(line)
                stripped = line.strip()

                if stripped.startswith('#') or stripped == '':
                    current_comment.append(line)
                    continue

                if stripped.startswith('[') and stripped.endswith(']'):
                    current_section = stripped[1:-1]
                    self.sections[current_section] = {}
                    self.comments[current_section] = {}
                    current_comment = []
                    continue

                if current_section and '=' in stripped:
                    key, value = stripped.split('=', 1)
                    key = key.strip()
                    value = value.strip()
                    self.sections[current_section][key] = value
                    if current_comment:
                        self.comments[current_section][key] = ''.join(current_comment)
                    current_comment = []

        return self.sections

    def get(self, section: str, key: str, default: str = '') -> str:
        return self.sections.get(section, {}).get(key, default)

    def set(self, section: str, key: str, value: Any) -> None:
        if section not in self.sections:
            self.sections[section] = {}

        if isinstance(value, bool):
            value = str(value)
        elif isinstance(value, (list, tuple)):
            value = ','.join(str(v) for v in value)
        else:
            value = str(value)

        self.sections[section][key] = value

    def add_section(self, section: str) -> None:
        if section not in self.sections:
            self.sections[section] = {}
            self.lines.append(f"\n[{section}]\n")

    def remove_section(self, section: str) -> bool:
        if section not in self.sections:
            return False
        
        del self.sections[section]
        
        new_lines = []
        in_section = False
        for line in self.lines:
            stripped = line.strip()
            if stripped.startswith('[') and stripped.endswith(']'):
                current = stripped[1:-1]
                if current == section:
                    in_section = True
                    continue
                else:
                    in_section = False
            if not in_section:
                new_lines.append(line)
        
        self.lines = new_lines
        return True

    def write(self) -> None:
        new_lines = []
        current_section = None
        written_keys = set()
        written_sections = set()

        for line in self.lines:
            stripped = line.strip()

            if stripped.startswith('#') or stripped == '':
                new_lines.append(line)
                continue

            if stripped.startswith('[') and stripped.endswith(']'):
                if current_section and current_section in self.sections:
                    section_written = written_keys.copy()
                    for key, value in self.sections[current_section].items():
                        if f"{current_section}.{key}" not in section_written:
                            new_lines.append(f"{key} = {value}\n")
                            written_keys.add(f"{current_section}.{key}")

                current_section = stripped[1:-1]
                written_sections.add(current_section)
                new_lines.append(line)
                continue

            if current_section and '=' in stripped:
                key = stripped.split('=', 1)[0].strip()
                if current_section in self.sections and key in self.sections[current_section]:
                    value = self.sections[current_section][key]
                    indent = len(line) - len(line.lstrip())
                    new_lines.append(' ' * indent + f"{key} = {value}\n")
                    written_keys.add(f"{current_section}.{key}")
                else:
                    new_lines.append(line)
                continue

            new_lines.append(line)

        if current_section and current_section in self.sections:
            for key, value in self.sections[current_section].items():
                if f"{current_section}.{key}" not in written_keys:
                    new_lines.append(f"{key} = {value}\n")
                    written_keys.add(f"{current_section}.{key}")

        for section, keys in self.sections.items():
            if section not in written_sections:
                new_lines.append(f"\n[{section}]\n")
                for key, value in keys.items():
                    new_lines.append(f"{key} = {value}\n")

        with open(self.path, 'w', encoding='utf-8') as f:
            f.writelines(new_lines)


def create_backup() -> str:
    os.makedirs(BACKUP_DIR, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
    backup_path = os.path.join(BACKUP_DIR, f"config-{timestamp}.ini")
    shutil.copy2(CONFIG_PATH, backup_path)
    return backup_path


def parse_value(value: str, field_type: str) -> Any:
    if field_type == 'boolean':
        return value.lower() in ('true', '1', 'yes', 'on')
    elif field_type == 'integer':
        try:
            return int(value)
        except ValueError:
            return 0
    elif field_type == 'float':
        try:
            return float(value)
        except ValueError:
            return 0.0
    elif field_type == 'list':
        return [v.strip() for v in value.split(',') if v.strip()]
    else:
        return value


def format_value(value: Any, field_type: str) -> str:
    if field_type == 'boolean':
        return str(bool(value))
    elif field_type == 'list':
        if isinstance(value, list):
            return ','.join(str(v) for v in value)
        return str(value)
    else:
        return str(value)


def get_interface_section_name(num: int) -> str:
    if num == 1:
        return "interface"
    return f"interface{num}"


def get_all_interfaces(parser: ConfigParser) -> Dict[int, Dict[str, Any]]:
    interfaces = {}
    
    for i in range(1, 10):
        section = get_interface_section_name(i)
        if section in parser.sections:
            config = {}
            fields = PRIMARY_INTERFACE_FIELDS if i == 1 else INTERFACE_FIELDS
            for key, field_info in fields.items():
                raw_value = parser.sections[section].get(key, '')
                if raw_value:
                    config[key] = parse_value(raw_value, field_info['type'])
                else:
                    config[key] = field_info.get('default', '')
            interfaces[i] = config
    
    return interfaces


# Schedule management functions
def load_schedules() -> List[Dict]:
    if SCHEDULES_PATH.exists():
        with open(SCHEDULES_PATH, 'r') as f:
            data = json.load(f)
            return data.get('schedules', [])
    return []


def save_schedules(schedules: List[Dict]) -> None:
    with open(SCHEDULES_PATH, 'w') as f:
        json.dump({'schedules': schedules}, f, indent=2)


def get_next_schedule_id(schedules: List[Dict]) -> int:
    if not schedules:
        return 1
    return max(s.get('id', 0) for s in schedules) + 1


# API Routes

@app.get("/", response_class=HTMLResponse)
async def root():
    html_path = Path(__file__).parent / "templates" / "index.html"
    if html_path.exists():
        return FileResponse(html_path)
    return HTMLResponse("<h1>MeshBOT Config Manager</h1><p>Loading...</p>")


@app.get("/api/schema")
async def get_schema():
    return {
        "schema": CONFIG_SCHEMA,
        "order": SECTION_ORDER,
        "interfaceFields": INTERFACE_FIELDS,
        "primaryInterfaceFields": PRIMARY_INTERFACE_FIELDS
    }


# Schedule endpoints

@app.get("/api/schedules")
async def get_schedules():
    """Get all custom schedules"""
    schedules = load_schedules()
    return {"schedules": schedules}


@app.get("/api/schedules/{schedule_id}")
async def get_schedule(schedule_id: int):
    """Get a specific schedule"""
    schedules = load_schedules()
    for s in schedules:
        if s.get('id') == schedule_id:
            return {"schedule": s}
    raise HTTPException(status_code=404, detail="Schedule not found")


@app.post("/api/schedules")
async def create_schedule(schedule: ScheduleItem):
    """Create a new schedule"""
    schedules = load_schedules()
    new_schedule = schedule.dict()
    new_schedule['id'] = get_next_schedule_id(schedules)
    schedules.append(new_schedule)
    save_schedules(schedules)
    return {"success": True, "schedule": new_schedule}


@app.put("/api/schedules/{schedule_id}")
async def update_schedule(schedule_id: int, schedule: ScheduleItem):
    """Update an existing schedule"""
    schedules = load_schedules()
    for i, s in enumerate(schedules):
        if s.get('id') == schedule_id:
            updated = schedule.dict()
            updated['id'] = schedule_id
            schedules[i] = updated
            save_schedules(schedules)
            return {"success": True, "schedule": updated}
    raise HTTPException(status_code=404, detail="Schedule not found")


@app.delete("/api/schedules/{schedule_id}")
async def delete_schedule(schedule_id: int):
    """Delete a schedule"""
    schedules = load_schedules()
    for i, s in enumerate(schedules):
        if s.get('id') == schedule_id:
            del schedules[i]
            save_schedules(schedules)
            return {"success": True, "deleted": schedule_id}
    raise HTTPException(status_code=404, detail="Schedule not found")


# Interface endpoints

@app.get("/api/interfaces")
async def get_interfaces():
    try:
        parser = ConfigParser(CONFIG_PATH)
        parser.read()
        interfaces = get_all_interfaces(parser)
        return {"interfaces": interfaces}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/interfaces/{num}")
async def get_interface(num: int):
    if num < 1 or num > 9:
        raise HTTPException(status_code=400, detail="Interface number must be 1-9")
    
    try:
        parser = ConfigParser(CONFIG_PATH)
        parser.read()
        section = get_interface_section_name(num)
        
        if section not in parser.sections:
            raise HTTPException(status_code=404, detail=f"Interface {num} not configured")
        
        interfaces = get_all_interfaces(parser)
        return {"interface": num, "config": interfaces.get(num, {})}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/interfaces")
async def add_interface(config: InterfaceUpdate):
    try:
        parser = ConfigParser(CONFIG_PATH)
        parser.read()
        
        next_num = None
        for i in range(2, 10):
            section = get_interface_section_name(i)
            if section not in parser.sections:
                next_num = i
                break
        
        if next_num is None:
            raise HTTPException(status_code=400, detail="Maximum 9 interfaces supported")
        
        backup_path = create_backup()
        
        section = get_interface_section_name(next_num)
        parser.add_section(section)
        
        for key, field_info in INTERFACE_FIELDS.items():
            value = getattr(config, key, None)
            if value is not None:
                parser.set(section, key, format_value(value, field_info['type']))
            else:
                parser.set(section, key, format_value(field_info['default'], field_info['type']))
        
        parser.write()
        
        return {
            "success": True,
            "interface": next_num,
            "section": section,
            "backup": backup_path
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/api/interfaces/{num}")
async def update_interface(num: int, config: InterfaceUpdate):
    if num < 1 or num > 9:
        raise HTTPException(status_code=400, detail="Interface number must be 1-9")
    
    try:
        parser = ConfigParser(CONFIG_PATH)
        parser.read()
        section = get_interface_section_name(num)
        
        if section not in parser.sections:
            raise HTTPException(status_code=404, detail=f"Interface {num} not configured")
        
        backup_path = create_backup()
        
        fields = PRIMARY_INTERFACE_FIELDS if num == 1 else INTERFACE_FIELDS
        for key, field_info in fields.items():
            value = getattr(config, key, None)
            if value is not None:
                parser.set(section, key, format_value(value, field_info['type']))
        
        parser.write()
        
        return {
            "success": True,
            "interface": num,
            "backup": backup_path
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/interfaces/{num}")
async def delete_interface(num: int):
    if num == 1:
        raise HTTPException(status_code=400, detail="Cannot delete primary interface")
    if num < 2 or num > 9:
        raise HTTPException(status_code=400, detail="Interface number must be 2-9")
    
    try:
        parser = ConfigParser(CONFIG_PATH)
        parser.read()
        section = get_interface_section_name(num)
        
        if section not in parser.sections:
            raise HTTPException(status_code=404, detail=f"Interface {num} not configured")
        
        backup_path = create_backup()
        
        parser.remove_section(section)
        parser.write()
        
        return {
            "success": True,
            "deleted": num,
            "backup": backup_path
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Config endpoints

@app.get("/api/config")
async def get_config():
    try:
        parser = ConfigParser(CONFIG_PATH)
        raw_config = parser.read()

        config = {}
        for section, fields in raw_config.items():
            config[section] = {}
            schema_section = CONFIG_SCHEMA.get(section, {}).get('fields', {})

            for key, value in fields.items():
                field_schema = schema_section.get(key, {})
                field_type = field_schema.get('type', 'string')
                config[section][key] = parse_value(value, field_type)

        return {"config": config, "path": CONFIG_PATH}
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Config file not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/config/backup")
async def backup_config():
    try:
        backup_path = create_backup()
        return {"success": True, "path": backup_path}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/config/backups")
async def list_backups():
    try:
        if not os.path.exists(BACKUP_DIR):
            return {"backups": []}

        backups = []
        for f in sorted(os.listdir(BACKUP_DIR), reverse=True):
            if f.startswith("config-") and f.endswith(".ini"):
                path = os.path.join(BACKUP_DIR, f)
                stat = os.stat(path)
                backups.append({
                    "filename": f,
                    "path": path,
                    "size": stat.st_size,
                    "modified": datetime.fromtimestamp(stat.st_mtime).isoformat()
                })

        return {"backups": backups}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/config/validate")
async def validate_config(config: Dict[str, Dict[str, Any]]):
    errors = []
    warnings = []

    for section, fields in config.items():
        if section not in CONFIG_SCHEMA:
            warnings.append(f"Unknown section: {section}")
            continue

        schema_section = CONFIG_SCHEMA[section].get('fields', {})

        for key, value in fields.items():
            if key not in schema_section:
                warnings.append(f"Unknown key: {section}.{key}")
                continue

            field_schema = schema_section[key]
            field_type = field_schema.get('type', 'string')

            if field_type == 'integer':
                try:
                    int(value) if not isinstance(value, int) else value
                except (ValueError, TypeError):
                    errors.append(f"{section}.{key}: Expected integer, got {type(value).__name__}")

            elif field_type == 'float':
                try:
                    float(value) if not isinstance(value, (int, float)) else value
                except (ValueError, TypeError):
                    errors.append(f"{section}.{key}: Expected float, got {type(value).__name__}")

            elif field_type == 'boolean':
                if not isinstance(value, bool) and str(value).lower() not in ('true', 'false', '1', '0', 'yes', 'no'):
                    errors.append(f"{section}.{key}: Expected boolean, got {value}")

            elif field_type == 'enum':
                options = field_schema.get('options', [])
                if value not in options:
                    errors.append(f"{section}.{key}: Value '{value}' not in allowed options: {options}")

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings
    }


@app.post("/api/config/restore/{filename}")
async def restore_backup(filename: str):
    try:
        backup_path = os.path.join(BACKUP_DIR, filename)
        if not os.path.exists(backup_path):
            raise HTTPException(status_code=404, detail="Backup not found")

        create_backup()

        shutil.copy2(backup_path, CONFIG_PATH)

        return {"success": True, "restored_from": backup_path}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/config/{section}")
async def get_section(section: str):
    try:
        parser = ConfigParser(CONFIG_PATH)
        raw_config = parser.read()

        if section not in raw_config:
            raise HTTPException(status_code=404, detail=f"Section '{section}' not found")

        schema_section = CONFIG_SCHEMA.get(section, {}).get('fields', {})
        config = {}

        for key, value in raw_config[section].items():
            field_schema = schema_section.get(key, {})
            field_type = field_schema.get('type', 'string')
            config[key] = parse_value(value, field_type)

        return {"section": section, "config": config}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/api/config/{section}")
async def update_section(section: str, updates: Dict[str, Any]):
    try:
        backup_path = create_backup()

        parser = ConfigParser(CONFIG_PATH)
        parser.read()

        if section not in parser.sections:
            raise HTTPException(status_code=404, detail=f"Section '{section}' not found")

        schema_section = CONFIG_SCHEMA.get(section, {}).get('fields', {})

        for key, value in updates.items():
            field_schema = schema_section.get(key, {})
            field_type = field_schema.get('type', 'string')
            formatted_value = format_value(value, field_type)
            parser.set(section, key, formatted_value)

        parser.write()

        return {
            "success": True,
            "section": section,
            "backup": backup_path,
            "updated_keys": list(updates.keys())
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/api/config")
async def update_config(bulk: BulkConfigUpdate):
    try:
        backup_path = create_backup()

        parser = ConfigParser(CONFIG_PATH)
        parser.read()

        updated = []

        for section, updates in bulk.updates.items():
            if section not in parser.sections:
                continue

            schema_section = CONFIG_SCHEMA.get(section, {}).get('fields', {})

            for key, value in updates.items():
                field_schema = schema_section.get(key, {})
                field_type = field_schema.get('type', 'string')
                formatted_value = format_value(value, field_type)
                parser.set(section, key, formatted_value)
                updated.append(f"{section}.{key}")

        parser.write()

        return {
            "success": True,
            "backup": backup_path,
            "updated": updated
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/service/status")
async def get_service_status():
    try:
        result = subprocess.run(
            ["docker", "inspect", "-f", "{{.State.Status}}", SERVICE_NAME],
            capture_output=True,
            text=True
        )

        if result.returncode == 0:
            status = result.stdout.strip()
        else:
            result = subprocess.run(
                ["systemctl", "is-active", SERVICE_NAME],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                status = result.stdout.strip()
            else:
                status = "unknown"

        return {
            "status": status,
            "service_name": SERVICE_NAME
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


@app.post("/api/service/restart")
async def restart_service():
    try:
        result = subprocess.run(
            ["docker", "restart", SERVICE_NAME],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            result = subprocess.run(
                ["sudo", "systemctl", "restart", SERVICE_NAME],
                capture_output=True,
                text=True
            )

        if result.returncode == 0:
            return {"success": True, "message": "Service restart initiated"}
        else:
            return {
                "success": False,
                "error": result.stderr or "Unknown error"
            }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/logs")
async def get_logs(lines: int = 100):
    try:
        log_path = "/opt/meshing-around/logs/prior_mesh.log"
        if not os.path.exists(log_path):
            log_path = "/opt/meshing-around/logs/prior_mesh.log"

        if os.path.exists(log_path):
            with open(log_path, 'r') as f:
                all_lines = f.readlines()
                return {"logs": all_lines[-lines:]}

        return {"logs": [], "message": "No log file found"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

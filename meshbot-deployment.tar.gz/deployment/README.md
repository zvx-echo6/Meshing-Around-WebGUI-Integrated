# MeshBOT Deployment

One-command deployment for MeshBOT with Web GUI.

## Quick Start

```bash
# Clone or download this deployment folder
cd deployment

# Run setup
./setup.sh

# Edit your configuration
nano config.ini    # Set your mesh node connection
nano .env          # Set timezone, ports, etc.

# Start services
docker compose up -d

# Access Web GUI
open http://localhost:8421
```

## Services

| Service | Description | Port |
|---------|-------------|------|
| meshbot | Main MeshBOT application | Host network |
| webgui | Web configuration UI | 8421 |
| ollama | Optional LLM (use `--profile llm`) | 11434 |

## Configuration

### Mesh Node Connection

Edit `config.ini` and set your connection type:

**TCP (recommended for remote nodes):**
```ini
[interface]
type = tcp
hostname = 192.168.1.251:4403
```

**Serial (for USB-connected nodes):**
```ini
[interface]
type = serial
port = /dev/ttyUSB0
```

Also uncomment the `devices` section in `docker-compose.yml` for serial.

### Multiple Interfaces

The Web GUI supports up to 9 interfaces. Add more via the Interfaces page.

### Scheduled Messages

1. Go to **Scheduler** in the Web GUI
2. Enable **"Use Custom Scheduler"**
3. Add your custom schedules below

## Commands

```bash
# Start services
docker compose up -d

# Start with LLM support
docker compose --profile llm up -d

# View logs
docker compose logs -f meshbot

# Restart after config changes
docker compose restart meshbot

# Stop everything
docker compose down

# Update to latest version
docker compose pull
docker compose up -d
```

## File Structure

```
deployment/
├── docker-compose.yml    # Service definitions
├── .env                  # Environment variables
├── config.ini            # MeshBOT configuration
├── config.template       # Config reference
├── setup.sh              # Setup script
├── data/                 # MeshBOT data (databases, etc.)
├── logs/                 # Log files
└── webgui/
    ├── Dockerfile        # Web GUI container
    ├── main.py           # FastAPI backend
    ├── templates/        # HTML templates
    ├── backups/          # Config backups
    └── schedules.json    # Custom schedules
```

## Troubleshooting

### Can't connect to mesh node

1. Verify the node IP is reachable: `ping 192.168.1.251`
2. Check if TCP port is open: `nc -zv 192.168.1.251 4403`
3. Ensure the node has TCP API enabled in Meshtastic settings

### Web GUI not loading

```bash
# Check container status
docker compose ps

# View webgui logs
docker compose logs webgui
```

### Service won't restart from Web GUI

Ensure Docker socket is mounted:
```yaml
volumes:
  - /var/run/docker.sock:/var/run/docker.sock:ro
```

## Backup & Restore

Backups are created automatically via the Web GUI and stored in `webgui/backups/`.

**Manual backup:**
```bash
cp config.ini config.ini.backup
cp webgui/schedules.json webgui/schedules.json.backup
```

**Restore:**
Use the Backups button in the Web GUI, or:
```bash
cp config.ini.backup config.ini
docker compose restart meshbot
```
